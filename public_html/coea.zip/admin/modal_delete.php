				
								
				<!---------------------------------- Delete Course modal ------------------------------------------>
    <div class="modal fade" id="Course_delete" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Course?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the Course  you checked? </p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_courses" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
<!--Delete Logs Modal -->
    <div class="modal fade" id="user_logs" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">�</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Users log?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the User log you checked?</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_user" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
<!--Delete Logs Modal -->
    <div class="modal fade" id="bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete System log?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the Activity log you checked?</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_log" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
<!--Delete dept Modal -->
    <div class="modal fade" id="dept_delete" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Department ?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the Department(s)  you checked?</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_dept" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
					<!--Delete fac Modal -->
    <div class="modal fade" id="fac_delete" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Faculty ?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the Faculty (s)  you checked?</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_fac" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
				<!--Delete fee Modal -->
    <div class="modal fade" id="fee_delete" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Fee ?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the Fee (s)  you checked?</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_fee" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
	<!--Delete fee Modal -->
    <div class="modal fade" id="pro_delete" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Program ?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the Program (s)  you checked?</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_pro" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
<!--Delete Session Modal -->
    <div class="modal fade" id="sec_delete" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Session ?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the Session (s)  you checked?</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_sec" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
								<!---------------------------------- Delete School modal ------------------------------------------>
    <div class="modal fade" id="Delete_school" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete School Setup Information?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the School Information  you checked? </p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_school" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
							<!---------------------------------- Delete School modal ------------------------------------------>
    <div class="modal fade" id="Delete_staff" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Staff Information?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the Staff Information  you checked? </p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_staff" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
						<!---------------------------------- Delete Bank modal ------------------------------------------>
    <div class="modal fade" id="bank_delete" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Bank Information?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the Bank Information  you checked? </p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_bank" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
					
					<!---------------------------------- Delete user modal ------------------------------------------>
    <div class="modal fade" id="user_delete" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete User Information?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the User Information  you checked? </p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_user" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
					
				<!---------------------------------- Delete hostel modal ------------------------------------------>
    <div class="modal fade" id="hostel_delete" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Hostel Information?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to delete the Hostel you checked? IF Done without Replacement it will affect records That use it to function.
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_hostel" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->

<!-- end  Modal -->
					
				<!---------------------------------- Delete student modal ------------------------------------------>
    <div class="modal fade" id="student_delete" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Student Information?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to delete the Student you checked? IF Done The student information would be lost Permanently.
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_student" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
					
					<!---------------------------------- Delete application student modal ------------------------------------------>
    <div class="modal fade" id="student_app" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Student Application Information?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to delete the Student Application you checked? IF Done The student information would be lost Permanently.
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_app" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
	<!---------------------------------- Delete Course allotment modal ------------------------------------------>
    <div class="modal fade" id="Course_allot" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Staff Course Allocation?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to delete the Staff Course Allotment you checked?
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_callot" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
					
					<!---------------------------------- Delete Lecture Set time modal ------------------------------------------>
    <div class="modal fade" id="LecSettime" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Lecture Time Set?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to delete the Lecture Time Set you checked?
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_lectime" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->

	
					<!---------------------------------- Delete uploaded Result modal ------------------------------------------>
    <div class="modal fade" id="delete_upresult" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Result?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to delete the Result you checked?
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_result" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
					<!---------------------------------- Delete payment modal ------------------------------------------>
    <div class="modal fade" id="delete_payment" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Payment?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to delete the Payment Information you checked?
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_payment" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
<!---------------------------------- Course Attandance modal ------------------------------------------>
    <div class="modal fade" id="course_attendance" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Course Attendance?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you Have Confirmed the Student Course Attendance you Selected?.
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="add_attend" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
				<!---------------------------------- Admin Delete uploaded Result modal ------------------------------------------>
    <div class="modal fade" id="delete_adminupresult" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Uploaded Result?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to delete the Result you checked?
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_aresult" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->

		<!---------------------------------- Admin Delete application form modal ------------------------------------------>
    <div class="modal fade" id="delete_appform" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Application Form(s)</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to delete the Form you checked?
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_appforms" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
	<!---------------------------------- Admin Delete application form modal ------------------------------------------>
    <div class="modal fade" id="delete_lform" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Programme level</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to delete the programme Level you checked?
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_lform" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
				<!---------------------------------- Admin Delete grade modal ------------------------------------------>
    <div class="modal fade" id="delete_grade" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete School Grade system</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to delete the grade you checked?
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_grade2" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
					
								<!---------------------------------- Admin Delete alloted room  ------------------------------------------>
    <div class="modal fade" id="delete_rallot" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Room allocation Information</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to delete room allocation information you checked?
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_allotroom" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
						
							<!---------------------------------- edit uploaded Student Result  ------------------------------------------>
    <div class="modal fade" id="save_upresult" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Result Confirmation</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>
Have you confirmed the modification made to this results you selected ?

</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="Saveupresult" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
												<!---------------------------------- Admin Delete entry  mode  ------------------------------------------>
    <div class="modal fade" id="delete_mode" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Entry mode Information</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to delete entry Mode information you checked?
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_mode" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->		
																<!---------------------------------- Delete role  ------------------------------------------>
    <div class="modal fade" id="delete_role" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Role Information</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to delete role information you checked?
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_role" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->	

														<!---------------------------------- update role permission  ------------------------------------------>
    <div class="modal fade" id="save_perm" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Update Role permission</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to Update role Permission you checked?
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="save_perm" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->	

							<!---------------------------------- Admin Delete alloted room  ------------------------------------------>
    <div class="modal fade" id="delete_position" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Position Information</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to delete Position information you checked?
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_posi" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
	
				
							<!---------------------------------- Admin Delete election  ------------------------------------------>
    <div class="modal fade" id="delete_elect" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Election Information</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
				<p>Are you sure you want to delete Election information you checked because the candidates under this election would be deleted?</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_elect" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->	
	<!---------------------------------- Admin Delete candidate  ------------------------------------------>
    <div class="modal fade" id="delete_candi" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Election Candidate</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
				<p>Are you sure you want to delete Election Candidate information you checked </p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_cand" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->	
	<!---------------------------------- Admin Approve  Course Reg  ------------------------------------------>
    <div class="modal fade" id="approve_c" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Approve Course Registration</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
				<p>Are you sure you want to Approve The selected Student Course Registration information you checked </p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="appcourse" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->	
<!---------------------------------- Admin Delete uploaded Result modal ------------------------------------------>
    <div class="modal fade" id="delete_courseup" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Courses Uploaded for <?php echo $SGdept1; ?> ?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>

Are you sure you want to delete the Selected Record you checked ?
</p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_acup" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->

			<!---------------------------------- Delete Course modal ------------------------------------------>
    <div class="modal fade" id="ftype_delete" tabindex="-1" role="dialog" aria-hidden="true">
    
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">

                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">x</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Delete Fee Type?</h4>
                        </div>
                       <div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the Fee Type  you checked? </p>
					</div>
					</div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Close</button>
                          <button  name="delete_ft" class="btn btn-primary"><i class="fa fa-check icon-large"></i>Yes</button>
                        </div>

                      </div>
                    </div>
                  </div>
<!-- end  Modal -->
