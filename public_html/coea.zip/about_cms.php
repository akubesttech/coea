

    <section id="content" role="document">
        <main style="min-height: 168px;">
                    <div class="container">
                        

<div class="row">
    <div class="col-xs-12">
        <div id="breadcrumbs-share">
            <section id="breadcrumbs">
                <ul class="breadcrumb">
                                <li><a href="<?php echo host(); ?>">Home</a> </li>


                    

                    

                </ul>
            </section>
        </div>
    </div>
</div>
                    </div>

            
<div class="container">
    <div class="row">
        <div class="col-xs-12 col-md-9">
            <div class="page-title-box">
                <h1 id="pageTitleStub">About CMSystem</h1>
                
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-xs-12 col-md-9 link-icons">
            <div class="row">
                <div class="col-xs-12 primary-content link-icons">
                    <p class="first-paragraph">
CMSystem is an online application portal that allows prospective/existing students and faculties access various educational services such as Admissions, Elearning, E-Library, Psychometric Assessments etc in any of the tertiary institutions in Delta State.</p>
                </div>
              <!--          <div class="col-xs-12">
            <h3>Stuff you might find helpful</h3>
        </div>
        <div class="margin-md-top row cards section-cards">
            <div class="col-xs-12">
                <div class="row nopadding nomargin" id="cards">
						<div class="col-xs-12 col-md-4 card card-half" onclick="window.open('main?view=Before_You_Start','_self')">
							<div class="card-content" style="background-image: url(./assets/media/apply-now2.jpg?anchor=center&amp;mode=crop&amp;width=800&amp;height=450&amp;rnd=131329381090000000);">
								<div class="col-sm-12 card-overlay">
									<div class="title">
										<a href="/main?view=Before_You_Start"><span class="name">Before You Start</span></a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-xs-12 col-md-4 card card-half" onclick="window.open('/main?view=Application_Process','_self')">
							<div class="card-content" style="background-image: url(./assets/media/application-process2.jpg?anchor=center&amp;mode=crop&amp;width=800&amp;height=450&amp;rnd=131190566240000000);">
								<div class="col-sm-12 card-overlay">
									<div class="title">
										<a href="/main?view=Application_Process"><span class="name">Application Process</span></a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-xs-12 col-md-4 card card-half" onclick="/main?view=Our_institutions','_self')">
							<div class="card-content" style="background-image: url(./assets/media/participating-institutions2.jpg?anchor=center&amp;mode=crop&amp;width=800&amp;height=450&amp;rnd=131193646260000000);">
								<div class="col-sm-12 card-overlay">
									<div class="title">
										<a href="/main?view=Our_institutions"><span class="name">Institutions</span></a>
									</div>
								</div>
							</div>
						</div>
                </div>
            </div>
        </div> --!>

            </div>
        </div>
        <div class="col-xs-12 col-md-3 sidebar-right margin-lg-bottom">
            <!-- right feature space -->
      <!--      
    <div class="apply-box">
        <a class="btn btn-default expand padding-md" href="Our_institution.htm">APPLY NOW</a>
    </div> --!>

<?php include("sidenews.php"); ?>
            
        </div>
    </div>
</div>


        </main>
    </section>
    
    